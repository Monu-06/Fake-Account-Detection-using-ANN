#Detect fake profiles in online social networks#



##install all python dependencies as mentioned below##

* pip
* numpy
* pandas
* ipython
* ipython notebook
* matplotlib
* sexmachine
* scikit-learn
* pybrain

## if you want to re-run code then it can be done in two ways-##
  1- using ipython notebook(recommneded)
  
     `$ ipython notebook`
	
      now all .ipynb files will be shown in browser, open any file and run 
  2- using python on terminal
  
     `$ python <file>.py`

